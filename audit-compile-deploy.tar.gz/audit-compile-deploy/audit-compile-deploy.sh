#!/bin/bash
#
# audit-compile-deploy
#
# prerequisites: 
#    - a set of audit rules exist in /etc/audit/rules.d
#    - a script in /etc/audit/rules.d that compiles a ruleset for setuid executables
# usage: run this script, it compiles audit rules, and injects the ruleset via auditctl


version="cis-rhel6-v2.0.0"
logfile=$PWD"/"$0.log
ts=$(date +%F-%H%M%S%Z)
echo "$ts started" > $logfile

[[ ! $(id -u) -eq 0 ]] && echo "not root, stopping." >> $logfile && exit 10

# check for auditctl (i.e. am I root)
[[ ! $(/sbin/auditctl -l) ]] && echo "no auditctl" >> $logfile && exit 11

#/sbin/augenrules --check >> $logfile # need an exit if rules ok
# ...skip this check and just do it because the command can't tell if the contents of rules.d has changed
#[[ $(/sbin/augenrules --check | grep -i "No change from running rules") ]] && echo "no rules change" >> $logfile && exit 0

[[ ! -d ./rules.d.$version ]] && echo "no new rules dir.  need a rules.d.$version below here to deploy from." >> $logfile && exit 11
[[ -d /etc/audit/rules.d ]] && mv /etc/audit/rules.d /etc/audit/rules.d.old-rules-$ts
cp -rp ./rules.d.$version /etc/audit/rules.d

# this must be done or they won't compile
[[ -e /etc/audit/audit.rules ]] && mv /etc/audit/audit.rules /etc/audit/audit.rules.old-rules-$ts

# fix all context
/sbin/restorecon -vFR /etc/audit

# build setuid rules
cd /etc/audit/rules.d
/etc/audit/rules.d/audit.rules.cis-rhel6-v2.0.0-4.1.12-priv_progs_usage_found.rules-generator.sh

echo "beginning rule gen" >> $logfile
# compile rules
/sbin/augenrules

# inject rules
/sbin/augenrules --load

echo "chkconfig auditd on" >> $logfile

chkconfig auditd on
service auditd restart

echo "$ts completed" >> $logfile
